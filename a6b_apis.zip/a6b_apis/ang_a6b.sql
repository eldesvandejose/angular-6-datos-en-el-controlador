-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-08-2018 a las 20:07:26
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ang_a6b_miembros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `role` enum('ROLE_ADMIN','ROLE_FULL','','') NOT NULL DEFAULT 'ROLE_ADMIN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `nombre`, `role`) VALUES
(1, 'admin', '$2y$10$iHYFwybJYLeuHHBnmC3G1updjPAPTyJNh55g6nNgKRdFgpULG/w3i', 'Admin de nivel bajo', 'ROLE_ADMIN'),
(2, 'admin_full', '$2y$10$GPss4u9eu7Q9nnpVjQeb0eetjxCeta7hAIKnyhxYpKr3lCb8aFRQC', 'Admin de nivel full', 'ROLE_FULL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socios`
--

CREATE TABLE `socios` (
  `id` int(11) NOT NULL,
  `doi` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fecha_de_ingreso` date NOT NULL,
  `genero` enum('H','M') NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'avatares/sin_avatar.jpg',
  `activo` enum('S','N') NOT NULL DEFAULT 'S'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `socios`
--

INSERT INTO `socios` (`id`, `doi`, `nombre`, `fecha_de_ingreso`, `genero`, `avatar`, `activo`) VALUES
(1, '994348938ZKDE', 'Agustín García Garrigues', '2015-04-25', 'H', 'avatares/lkfekl4flsk393909wjcffwj09fealjf.jpg', 'S'),
(2, '09ILK4LMWL4', 'Elisa Fernández De Lima', '2015-07-01', 'M', 'avatares/lknf4wlkmn9w4f94505oprwkrwrwjr43.jpg', 'S'),
(3, 'LJKRJFNK44S4', 'Manfredo Torres Redondo', '2016-05-18', 'H', 'avatares/kllwe924i99kñl23k40320rkrwo3wño0.jpg', 'S'),
(4, 'ASLKJ3LK4LRFLKF4', 'María Fernanda Gómez De La Causa', '2017-08-17', 'M', 'avatares/sin_avatar.jpg', 'S'),
(5, 'LKJSF3093023', 'Manuel Torres Aranda', '2018-08-01', 'H', 'avatares/sin_avatar.jpg', 'S'),
(6, 'LKRFJ$304093', 'Alicia Gracia Gómez', '2018-08-23', 'M', 'avatares/sin_avatar.jpg', 'S'),
(7, 'HKELR08943409', 'Francisco Nardine', '2018-08-21', 'H', 'avatares/sin_avatar.jpg', 'S'),
(8, 'DSKFFJLKFJSSR5403', 'Luis Guerra Aguas', '2018-06-19', 'H', 'avatares/sin_avatar.jpg', 'S'),
(9, 'GSÑLGÑL049823243', 'María Peñas De Luis', '2018-08-15', 'M', 'avatares/sin_avatar.jpg', 'S'),
(10, 'FGLÑRL8429095443', 'Pedro León Azkoitia', '2018-08-14', 'H', 'avatares/sin_avatar.jpg', 'S'),
(11, 'FEH$WIJ0348902rjkke', 'Gabriela Fernández', '2018-08-08', 'M', 'avatares/sin_avatar.jpg', 'S'),
(12, 'KLJKJSF0429834', 'Marta González Garrido', '2018-08-22', 'M', 'avatares/sin_avatar.jpg', 'S'),
(13, 'NNNeEE3040983409', 'Juan Carlos Sangrador Almeida', '2018-03-06', 'H', 'avatares/sin_avatar.jpg', 'S'),
(14, 'MDKEKLW493200203', 'María Antonia De las Torres Doradas', '2018-08-14', 'M', 'avatares/sin_avatar.jpg', 'S'),
(15, 'KLDLE40302221', 'Jacinto Vázquez De León', '2018-08-13', 'H', 'avatares/sin_avatar.jpg', 'S'),
(16, 'JLLDRLEL049590303', 'Leona Andrino', '2018-08-29', 'M', 'avatares/sin_avatar.jpg', 'S'),
(17, 'MKFKRNK030020222', 'Elena De Domingo Blanco', '2018-08-07', 'M', 'avatares/sin_avatar.jpg', 'S'),
(18, 'LSFGÑKSR40303023', 'Martina Pérez Córdoba', '2018-08-21', 'M', 'avatares/sin_avatar.jpg', 'S'),
(19, 'CMDDMMMM44493E', 'Gabriel Costa Borrego', '2018-08-07', 'H', 'avatares/sin_avatar.jpg', 'S'),
(20, 'JRKKKWWK39949493', 'María Del Sagrario Diablo', '2018-08-07', 'M', 'avatares/sin_avatar.jpg', 'S'),
(21, 'LELRKELKE09842302934', 'Marina Del Agua', '2018-08-29', 'M', 'avatares/sin_avatar.jpg', 'S'),
(22, 'JFLFLRLo49930220', 'Antonio de la Cabrera Sierra', '2018-08-07', 'H', 'avatares/sin_avatar.jpg', 'S'),
(23, 'ÑLSFKFSÑL499495954', 'Pedro Gatos Pardos', '2018-08-08', 'H', 'avatares/sin_avatar.jpg', 'S'),
(24, 'RRDEEER4i5o5o939', 'Ángela Montes Claros', '2018-08-05', 'M', 'avatares/sin_avatar.jpg', 'S');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `indice_login` (`login`);

--
-- Indices de la tabla `socios`
--
ALTER TABLE `socios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `index_doi` (`doi`(191)) USING BTREE,
  ADD KEY `nombre_index` (`nombre`(191)),
  ADD KEY `fecha_de_ingreso_index` (`fecha_de_ingreso`),
  ADD KEY `genero_index` (`genero`),
  ADD KEY `avatar_index` (`avatar`(191)),
  ADD KEY `activo_index` (`activo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `socios`
--
ALTER TABLE `socios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
