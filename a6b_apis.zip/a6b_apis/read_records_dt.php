<?php
  include_once ('db_conn.php');

  $datos = json_decode(file_get_contents('php://input'), true);

  // Leemos los datos de los miembros, filtrados y ordenados según los criterios establecidos en la llamada.
  $consulta = "SELECT ";
  $consulta .= "doi, ";
  $consulta .= "nombre, ";
  $consulta .= "fecha_de_ingreso, ";
  $consulta .= "id ";
  $consulta .= "FROM socios ";
  $consulta .= "WHERE ";
  $consulta .= "doi LIKE '%".$datos["search"]["value"]."%' ";
  $consulta .= "OR nombre LIKE '%".$datos["search"]["value"]."%' ";
  $consulta .= "ORDER BY ".$datos["columns"][$datos["order"][0]["column"]]["data"]." ".$datos["order"][0]["dir"];
  if ($datos["length"] > 0) $consulta .= " LIMIT ".$datos["start"].", ".$datos["length"];
  $consulta .= ";";
  $hacerConsulta = $conexion->query($consulta);
  $membersArray = $hacerConsulta->fetchAll(PDO::FETCH_ASSOC);
  $hacerConsulta->closeCursor();

  // A todos los miembros les cambiamos la fecha de alta al formato español
  foreach ($membersArray as $keyMember=>$member) {
    $membersArray[$keyMember]["fecha_de_ingreso"] = date("d-m-Y", strtotime($member["fecha_de_ingreso"]));
  }

  // Contamos el total de miembros que cumplen los requisitos de búsqueda,
  // sin establecer limitación
  $consulta = "SELECT COUNT(*) ";
  $consulta .= "FROM socios ";
  $consulta .= "WHERE ";
  $consulta .= "doi LIKE '%".$datos["search"]["value"]."%' ";
  $consulta .= "OR nombre LIKE '%".$datos["search"]["value"]."%';";
  $hacerConsulta = $conexion->query($consulta);
  $filtrados = (int)$hacerConsulta->fetch(PDO::FETCH_ASSOC)["COUNT(*)"];
  $hacerConsulta->closeCursor();

  // Contamos el total de miembros de la tabla.
  $consulta = "SELECT COUNT(*) ";
  $consulta .= "FROM socios;";
  $hacerConsulta = $conexion->query($consulta);
  $totales = (int)$hacerConsulta->fetch(PDO::FETCH_ASSOC)["COUNT(*)"];
  $hacerConsulta->closeCursor();

  $datosDeRetorno = [
    "draw"=>$datos["draw"],
    "recordsTotal"=>$totales,
    "recordsFiltered"=>$filtrados,
    "data"=>$membersArray
  ];

  $datosDeRetorno = json_encode($datosDeRetorno);

  echo $datosDeRetorno;
?>
