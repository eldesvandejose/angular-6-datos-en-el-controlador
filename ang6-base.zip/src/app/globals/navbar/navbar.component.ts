import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'a6b-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Input() nombreAdmin: string;
  @Input() rolAdmin: string;

  constructor() {}

  ngOnInit() { }
}
